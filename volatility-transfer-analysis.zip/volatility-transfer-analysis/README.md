# Cross-Market Transfer of Volatility Forecasting Models

A single script that runs the full analysis: six model families (GARCH(1,1), HAR, ridge, random forest, XGBoost, LSTM) are each fitted on one of five equity indices (S&P 500, NIFTY 50, FTSE 100, Nikkei 225, DAX) and applied, with no retraining, to all five.

- **Target:** log of five-day-ahead realised volatility (Parkinson range estimator)
- **Loss:** QLIKE; RMSE (log scale) and out-of-sample R² are reported alongside
- **Splits:** chronological and purged. Train to 2016-12-31, validation to 2019-12-31, test after
- **Inference:** paired moving-block bootstrap, Diebold-Mariano tests, pooled model confidence set, recalibration comparison, seed-noise floor
- **Extras:** fitted GARCH/GJR parameters and an India-only variance-risk-premium ablation

## Run

```bash
pip install -r requirements.txt
python volatility_transfer_analysis.py              # full run, including the LSTM
python volatility_transfer_analysis.py --skip-lstm  # five models, faster
```

Price data is downloaded from Yahoo Finance on first run and cached in `data_raw/`. Tables are written to `results/` and the transfer-matrix figure to `figs/`. A full run takes roughly five minutes on a recent laptop CPU. `results/run_info.json` records the Python and library versions, settings and data dates of each run.

## Outputs

| Output | File |
|---|---|
| Own-market and transfer QLIKE | `results/cmp_qlike_<model>.csv`, `cmp_headline.csv`, `cmp_own_market.csv` |
| Seed-noise floor | `results/cmp_seed_noise.csv` |
| Paired bootstrap vs HAR | `results/cmp_paired_vs_har.csv` |
| Diebold-Mariano vs HAR | `results/cmp_dm_vs_har.csv` |
| Pooled model confidence set | `results/cmp_mcs_pooled.csv` |
| Recalibration comparison | `results/cmp_recalibration.csv` |
| Fitted GARCH parameters | `results/table_garch_parameters.csv` |
| VRP ablation | `results/table_vrp_ablation.csv` |
| Per-day loss series | `results/losses_<market>.csv` |

## Reproducibility notes

- Fixed settings (tickers, windows, splits, seeds, bootstrap sizes) are at the top of the script. Seeds are fixed for every stochastic model.
- Yahoo Finance can revise historical prices. For an exact rerun, keep the cached `data_raw/` files from the original run.
- Tested with Python 3.12, numpy 2.5, pandas 3.1, scikit-learn 1.9, xgboost 3.4, arch 9.0, tensorflow 2.21. In that environment the GARCH, HAR, ridge and LSTM results reproduce the reference run to four decimals and the random forest to within 0.0003.
- XGBoost results depend on the library version and hardware. Across environments its own-market QLIKE differed by up to about 0.005, which can move one model-confidence-set membership slot. The LSTM is not bit-deterministic across hardware.
