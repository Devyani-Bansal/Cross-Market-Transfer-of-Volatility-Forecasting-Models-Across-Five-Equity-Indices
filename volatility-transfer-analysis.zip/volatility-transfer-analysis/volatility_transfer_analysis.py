"""Cross-market transfer of volatility forecasting models.

Fits six model families (GARCH(1,1), HAR, ridge, random forest, XGBoost, LSTM) on each of five equity
indices, applies every fitted model to all five without retraining, and evaluates on a common set of
test days. Produces every table in the analysis:

  data audit and splits ................. printed
  own-market and transfer QLIKE .......... results/cmp_qlike_*.csv, cmp_headline.csv, cmp_own_market.csv
  seed-noise floor ....................... results/cmp_seed_noise.csv
  paired bootstrap vs HAR ................ results/cmp_paired_vs_har.csv
  Diebold-Mariano vs HAR ................. results/cmp_dm_vs_har.csv
  pooled model confidence set ............ results/cmp_mcs_pooled.csv
  recalibration arm ...................... results/cmp_recalibration.csv
  fitted GARCH parameters ................ results/table_garch_parameters.csv
  India VRP ablation ..................... results/table_vrp_ablation.csv
  run record (versions, data dates) ....... results/run_info.json

Usage:
    python volatility_transfer_analysis.py              # full run, including the LSTM (slow)
    python volatility_transfer_analysis.py --skip-lstm  # five models, fast
"""
import argparse

_parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
_parser.add_argument("--skip-lstm", action="store_true", help="skip the LSTM (five-model pass)")
args = _parser.parse_args()

# ============================================================================
# 0. Configuration
# ============================================================================
import os
import warnings
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm

from sklearn.linear_model import LinearRegression
from sklearn.preprocessing import StandardScaler

from sklearn.linear_model import Ridge
from sklearn.ensemble import RandomForestRegressor
from xgboost import XGBRegressor
from arch import arch_model
from scipy.stats import t as student_t

from arch.bootstrap import MCS, SPA

warnings.filterwarnings("ignore")

TICKERS = {
    "^GSPC": "US_SP500",
    "^NSEI": "India_NIFTY50",
    "^FTSE": "UK_FTSE100",
    "^N225": "Japan_Nikkei225",
    "^GDAXI": "Germany_DAX",
}
MARKETS = list(TICKERS.values())

DL_START, DL_END = "2005-01-01", "2026-08-01"
WIN_START = "2007-09-18"
HORIZON = 5
PURGE = HORIZON
TRAIN_END, VAL_END = "2016-12-31", "2019-12-31"
TARGET = "log_rv"
DROP = [TARGET]
HAR_COLS = ["vol_5", "vol_21", "vol_63"]
N_SEEDS = 5
N_BOOT = 500
BLOCK = 21

# Feature policy: `gap = log(Open / prior Close)` is removed because for the FTSE it measures a
# vendor artefact (96.4% of its opens are copies of the prior close) rather than an overnight return.
GAP_POLICY = "drop"
CLIP_Z = 8.0          # only used when GAP_POLICY == "clip"
assert GAP_POLICY in ("drop", "clip", "keep")

INCLUDE_LSTM = not args.skip_lstm   # --skip-lstm = fast 5-model pass without the LSTM refit

MODELS = ["garch", "har", "ridge", "rf", "xgb"] + (["lstm"] if INCLUDE_LSTM else [])
LABEL = {"garch": "GARCH", "har": "HAR", "ridge": "Ridge",
         "rf": "RandomForest", "xgb": "XGBoost", "lstm": "LSTM"}
IS_STOCHASTIC_KIND = {"garch": False, "har": False, "ridge": False,
                      "rf": True, "xgb": True, "lstm": True}
BENCHMARK = "har"            # the reference for SPA and the DM tests

SEQ_LEN = 21                 # LSTM input window
LSTM_UNITS, DROPOUT, EPOCHS, BATCH, PATIENCE, LR = 32, 0.20, 80, 64, 10, 1e-3
RIDGE_ALPHA = 1.0       # Ridge penalty; fixed across markets so models stay comparable

for folder in ("data_raw", "figs", "results"):
    os.makedirs(folder, exist_ok=True)

plt.rcParams.update({
    "figure.dpi": 110,
    "savefig.dpi": 160,
    "font.size": 9,
    "axes.titlesize": 10,
    "axes.spines.top": False,
    "axes.spines.right": False,
})

if INCLUDE_LSTM:
    import tensorflow as tf
    from tensorflow.keras.models import Sequential
    from tensorflow.keras.layers import Input, LSTM, Dense, Dropout
    from tensorflow.keras.optimizers import Adam
    from tensorflow.keras.callbacks import EarlyStopping

print("models:", MODELS, "|", len(MARKETS), "markets | GAP_POLICY =", GAP_POLICY)
if not INCLUDE_LSTM:
    print("LSTM EXCLUDED: every table below covers 5 models, not 6.")

# ============================================================================
# 1. Data and audit
# ============================================================================
import time, random
import requests
from urllib.parse import quote

_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
       "(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")
_sess = requests.Session()
_sess.headers.update({"User-Agent": _UA, "Accept": "application/json"})
for _warm in ("https://finance.yahoo.com", "https://fc.yahoo.com"):
    try:
        _sess.get(_warm, timeout=30)
    except Exception:
        pass

def _fetch_chart(ticker):
    params = {"period1": int(pd.Timestamp(DL_START).timestamp()),
              "period2": int(pd.Timestamp(DL_END).timestamp()),
              "interval": "1d"}
    hosts = ["https://query1.finance.yahoo.com", "https://query2.finance.yahoo.com"]
    last = None
    for attempt in range(8):
        try:
            r = _sess.get(hosts[attempt % 2] + "/v8/finance/chart/" + quote(ticker),
                          params=params, timeout=30)
            if r.status_code == 200:
                return r.json()["chart"]["result"][0]
            last = "HTTP " + str(r.status_code)
        except Exception as e:
            last = str(e)
        time.sleep(6 * (attempt + 1) + random.uniform(0, 4))
    raise RuntimeError("chart fetch failed for " + ticker + " (" + str(last) + ")")

def download_series(ticker, name):
    path = os.path.join("data_raw", name + ".parquet")
    if os.path.exists(path):
        return pd.read_parquet(path)
    result = _fetch_chart(ticker)
    q = result["indicators"]["quote"][0]
    frame = pd.DataFrame({"Open": q["open"], "High": q["high"],
                          "Low": q["low"], "Close": q["close"]},
                         index=pd.to_datetime(result["timestamp"], unit="s"))
    frame.index = frame.index.tz_localize(None).normalize()
    frame = frame.dropna()
    if len(frame) == 0:
        raise RuntimeError("download failed for " + ticker + " (" + name + ")")
    frame.to_parquet(path)
    time.sleep(3)
    return frame

raw = {}
for ticker, name in TICKERS.items():
    raw[name] = download_series(ticker, name)
    print(name.ljust(18), "rows =", str(len(raw[name])).rjust(5), " ",
          raw[name].index.min().date(), "to", raw[name].index.max().date())

try:
    vix_raw = download_series("^INDIAVIX", "India_VIX")
    HAVE_VIX = True
    print("India_VIX".ljust(18), "rows =", str(len(vix_raw)).rjust(5), " ",
          vix_raw.index.min().date(), "to", vix_raw.index.max().date())
except Exception as error:
    print("India VIX unavailable (" + str(error) + "); the VRP ablation will be skipped.")
    HAVE_VIX = False

# ============================================================================
# 1. Data and audit
# ============================================================================
def open_matches_prior_close(frame, tolerance=1e-9):
    prior_close = frame["Close"].shift(1)
    return (frame["Open"] - prior_close).abs() <= tolerance * prior_close


yz_valid_from = {}
FAKE_OPEN_FRAC = {}
for name in MARKETS:
    frame = raw[name]
    fake_open = open_matches_prior_close(frame)
    FAKE_OPEN_FRAC[name] = float(fake_open.mean())
    rolling_fake = fake_open.rolling(252).mean()
    usable = rolling_fake[rolling_fake < 0.01].index.min()
    yz_valid_from[name] = usable
    print(name.ljust(18), "fake-Open fraction =", round(FAKE_OPEN_FRAC[name], 3),
          " Yang-Zhang usable from:", usable.date() if pd.notna(usable) else "never")

# Are High and Low also synthesised? If the vendor fabricates Open for a market it may fabricate
# the range too - which would corrupt vol_5/21/63, `range`, `close_loc` AND THE TARGET ITSELF for
# that market, a far worse problem than a single bad feature. The range is checked separately because the Open defect says nothing about
# whether the same market's range is intact.
print()
print("Range integrity check (is High/Low degenerate where Open is fabricated?)")
RANGE_AUDIT = {}
for name in MARKETS:
    frame = raw[name]
    body_hi = np.maximum(frame["Open"], frame["Close"])
    body_lo = np.minimum(frame["Open"], frame["Close"])
    pinned = float(((frame["High"] - body_hi).abs() <= 1e-9 * body_hi).mean())
    pinned_lo = float(((frame["Low"] - body_lo).abs() <= 1e-9 * body_lo).mean())
    rng = float(np.log(frame["High"] / frame["Low"]).mean())
    RANGE_AUDIT[name] = {"high_pinned_to_body": round(pinned, 3),
                         "low_pinned_to_body": round(pinned_lo, 3),
                         "mean_log_range": round(rng, 5)}
    print("  " + name.ljust(18) + " High==max(O,C) on " + format(pinned, ".3f")
          + " of days, Low==min(O,C) on " + format(pinned_lo, ".3f")
          + ", mean log range " + format(rng, ".5f"))
_rng_vals = [v["mean_log_range"] for v in RANGE_AUDIT.values()]
print()
print("  Mean log range spread across markets:",
      round(max(_rng_vals) / min(_rng_vals), 2), "x")
print("  A market whose High/Low were fabricated would show a pinned fraction near 1 and/or a")
print("  markedly smaller mean range. If all five look comparable, the Open defect is confined")
print("  to the `gap` feature and does NOT contaminate the volatility target.")

for name in MARKETS:
    close = raw[name]["Close"].dropna()
    ret = np.log(close).diff().dropna()
    z = (ret - ret.mean()) / ret.std()
    extreme = ret[z.abs() > 8] * 100
    print()
    print(name, "greater than 8 sigma days, kept as real market events:")
    print(extreme.round(2).to_string() if len(extreme) else "  none")

# ============================================================================
# 2. Volatility estimators, features and target
# ============================================================================
def parkinson_vol(frame, window):
    log_hl_sq = np.log(frame["High"] / frame["Low"]) ** 2
    return np.sqrt(log_hl_sq.rolling(window).mean() / (4.0 * np.log(2.0)))


def garman_klass_vol(frame, window):
    log_hl_sq = np.log(frame["High"] / frame["Low"]) ** 2
    log_co_sq = np.log(frame["Close"] / frame["Open"]) ** 2
    gk = 0.5 * log_hl_sq - (2.0 * np.log(2.0) - 1.0) * log_co_sq
    return np.sqrt(gk.rolling(window).mean().clip(lower=0))


def yang_zhang_vol(frame, window):
    open_, high, low, close = frame["Open"], frame["High"], frame["Low"], frame["Close"]
    prior_close = close.shift(1)
    overnight = np.log(open_ / prior_close) ** 2
    open_to_close = np.log(close / open_) ** 2
    rs = np.log(high / close) * np.log(high / open_) + np.log(low / close) * np.log(low / open_)
    k = 0.34 / (1.34 + (window + 1) / (window - 1))
    var_overnight = overnight.rolling(window).var()
    var_open_close = open_to_close.rolling(window).var()
    var_rs = rs.rolling(window).mean()
    return np.sqrt((var_overnight + k * var_open_close + (1.0 - k) * var_rs).clip(lower=0))

# ============================================================================
# 2. Volatility estimators, features and target
# ============================================================================
def make_features(frame):
    open_, high, low, close = frame["Open"], frame["High"], frame["Low"], frame["Close"]
    ret = np.log(close).diff()
    feats = pd.DataFrame(index=frame.index)

    for lag in range(1, 6):
        feats["ret_lag" + str(lag)] = ret.shift(lag - 1)

    for window in (5, 21, 63):
        feats["vol_" + str(window)] = np.log(parkinson_vol(frame, window) + 1e-8)
    feats["vol_ratio"] = feats["vol_5"] - feats["vol_63"]

    for window in (21, 63, 126):
        feats["mom_" + str(window)] = np.log(close / close.shift(window))

    delta = close.diff()
    gain = delta.clip(lower=0)
    loss = (-delta).clip(lower=0)
    avg_gain = gain.ewm(alpha=1.0 / 14.0, adjust=False).mean()
    avg_loss = loss.ewm(alpha=1.0 / 14.0, adjust=False).mean()
    rs = avg_gain / (avg_loss + 1e-8)
    feats["rsi_14"] = 100.0 - 100.0 / (1.0 + rs)

    ema12 = close.ewm(span=12, adjust=False).mean()
    ema26 = close.ewm(span=26, adjust=False).mean()
    macd = (ema12 - ema26) / close
    feats["macd"] = macd
    feats["macd_sig"] = macd.ewm(span=9, adjust=False).mean()
    feats["macd_hist"] = feats["macd"] - feats["macd_sig"]

    for window in (21, 63, 200):
        feats["ma_dist_" + str(window)] = np.log(close / close.rolling(window).mean())

    feats["range"] = np.log(high / low)
    feats["close_loc"] = (close - low) / (high - low + 1e-8)
    feats["gap"] = np.log(open_ / close.shift(1))
    feats["dow"] = frame.index.dayofweek
    return feats


def make_target(frame, horizon=HORIZON):
    trailing = parkinson_vol(frame, horizon)
    forward = trailing.shift(-horizon)
    out = pd.DataFrame(index=frame.index)
    out[TARGET] = np.log(forward + 1e-8)
    return out


def build(frame, horizon=HORIZON):
    return make_features(frame).join(make_target(frame, horizon)).dropna()

# ============================================================================
# 2a. Unit tests
# ============================================================================
# Each of the five tests below targets a failure mode that
# produces plausible-looking output rather than an error, which is why they are executable
# assertions rather than eyeball checks.
_rng = np.random.default_rng(0)
_n = 600
_close = 100 * np.exp(np.cumsum(_rng.normal(0, 0.01, _n)))
_high = _close * np.exp(np.abs(_rng.normal(0, 0.006, _n)))
_low = _close * np.exp(-np.abs(_rng.normal(0, 0.006, _n)))
_open = np.r_[_close[0], _close[:-1]] * np.exp(_rng.normal(0, 0.004, _n))
_test = pd.DataFrame({"Open": _open, "High": _high, "Low": _low, "Close": _close},
                     index=pd.bdate_range("2010-01-01", periods=_n))

# TEST 1: the target at date t must equal trailing Parkinson RV computed at t + HORIZON.
_built = build(_test)
_trail = parkinson_vol(_test, HORIZON)
_pos = 200
_date = _built.index[_pos]
_fwd_date = _test.index[_test.index.get_loc(_date) + HORIZON]
assert np.isclose(_built[TARGET].iloc[_pos], np.log(_trail.loc[_fwd_date] + 1e-8)), "TEST 1 FAILED"
print("TEST 1  forward Parkinson-RV alignment    PASS")

# TEST 2: no feature may change when data strictly after t is altered.
# NOTE: the tamper must change the high/low RATIO, not the price level. Multiplying all four OHLC columns by a constant would be
# useless, because TEST 3 separately proves every feature ignores it, so it could never fail. Widening the
# range is a change no scale-free feature is allowed to be invariant to.
_tampered = _test.copy()
_cut = _tampered.index[400]
_tampered.loc[_cut:, "High"] *= 1.05
_tampered.loc[_cut:, "Low"] /= 1.05
_a = make_features(_test).iloc[:400]
_b = make_features(_tampered).iloc[:400]
assert np.allclose(_a.values, _b.values, equal_nan=True), "TEST 2 FAILED (look-ahead in features)"
# and the tamper must be detectable at all, otherwise the test is vacuous
_after = make_features(_tampered).iloc[401:450]
assert not np.allclose(make_features(_test).iloc[401:450].values, _after.values, equal_nan=True), \
    "TEST 2 INVALID (the tamper changes nothing, so the test proves nothing)"
print("TEST 2  no look-ahead in features         PASS")

# TEST 3: features must be invariant to the index level - the property cross-market transfer
# depends on arithmetically. NIFTY trades near 20,000 and the FTSE near 7,000.
_scaled = _test * 7.3
_f1, _f2 = make_features(_test), make_features(_scaled)
assert np.allclose(_f1.values, _f2.values, equal_nan=True), "TEST 3 FAILED (features not scale-free)"
print("TEST 3  feature scale invariance          PASS")

# TEST 4: the target must likewise not depend on the price level.
assert np.allclose(make_target(_test).values, make_target(_scaled).values, equal_nan=True), "TEST 4 FAILED"
print("TEST 4  target scale invariance           PASS")

# TEST 5: the target must not be the trailing window - that would be predicting the past.
_trailing_log = np.log(parkinson_vol(_test, HORIZON) + 1e-8)
_joined = pd.concat([_built[TARGET], _trailing_log.rename("trailing")], axis=1).dropna()
assert not np.allclose(_joined[TARGET].values, _joined["trailing"].values), "TEST 5 FAILED"
print("TEST 5  forward != trailing target        PASS")

# ============================================================================
# 2b. Build modelling datasets
# ============================================================================
data = {}
for name in MARKETS:
    ohlc = raw[name][["Open", "High", "Low", "Close"]].loc[WIN_START:]
    data[name] = build(ohlc)

common = max(frame.index.min() for frame in data.values())
data = {name: frame.loc[common:] for name, frame in data.items()}

print("common start:", common.date())
for name, frame in data.items():
    print(name.ljust(18), str(len(frame)).rjust(5), "rows ",
          frame.index.min().date(), "to", frame.index.max().date())

FEATS = [column for column in data[MARKETS[0]].columns if column not in DROP]

# GAP_POLICY == "drop": remove the only Open-dependent feature. For the FTSE, `Open` is a copy
# of the prior close on 96.4% of sessions (see the data audit), so `gap` is not the same measurement
# across these five markets and is not a legitimate member of a shared feature set.
if GAP_POLICY == "drop":
    FEATS = [column for column in FEATS if column != "gap"]

print()
print(len(FEATS), "features  (GAP_POLICY =", GAP_POLICY, ")")
if GAP_POLICY == "drop":
    print("  'gap' removed from the shared feature set.")

# ============================================================================
# 3. Splits (purged, chronological)
# ============================================================================
def split(frame):
    train = frame.loc[:TRAIN_END].iloc[:-PURGE]
    val = frame.loc[TRAIN_END:VAL_END].iloc[PURGE:-PURGE]
    test = frame.loc[VAL_END:].iloc[PURGE:]
    return train, val, test


SPL = {name: split(data[name]) for name in MARKETS}
for name in MARKETS:
    train, val, test = SPL[name]
    assert train.index.max() < val.index.min() and val.index.max() < test.index.min()
    print(name.ljust(18), "train =", str(len(train)).rjust(5),
          " val =", str(len(val)).rjust(4), " test =", str(len(test)).rjust(5))

# ============================================================================
# 4. All six model layers behind one interface
# ============================================================================
RET = {}
for name in MARKETS:
    close = raw[name]["Close"].loc[WIN_START:]
    RET[name] = (100.0 * np.log(close).diff()).dropna()

MARKET_OF_FRAME = {}
for name in MARKETS:
    for part in SPL[name]:
        MARKET_OF_FRAME[id(part)] = name


def uses_scaler(kind):
    return kind in ("har", "ridge", "lstm")


def apply_scaling(scaler, frame, columns):
    if scaler is None:
        return frame[columns].values
    z = scaler.transform(frame[columns].values)
    return np.clip(z, -CLIP_Z, CLIP_Z) if GAP_POLICY == "clip" else z


def make_model(kind, seed=0):
    if kind == "har":
        return LinearRegression()
    if kind == "ridge":
        return Ridge(alpha=RIDGE_ALPHA)
    if kind == "rf":
        return RandomForestRegressor(n_estimators=300, max_depth=8, min_samples_leaf=20,
                                     n_jobs=-1, random_state=seed)
    if kind == "xgb":
        return XGBRegressor(n_estimators=400, max_depth=4, learning_rate=0.03,
                            subsample=0.8, colsample_bytree=0.8, reg_lambda=1.0,
                            n_jobs=-1, random_state=seed, verbosity=0)
    raise ValueError(kind)


# ---------- GARCH ----------
def fit_garch_params(source, seed=0):
    r = RET[source].loc[:SPL[source][0].index.max()]
    res = arch_model(r, vol="GARCH", p=1, q=1, mean="Constant", dist="normal").fit(
        disp="off", show_warning=False)
    p = res.params
    out = {"omega": float(p["omega"]), "alpha": float(p["alpha[1]"]), "beta": float(p["beta[1]"]),
           "gamma": 0.0, "mu": float(p["mu"]), "variant": "garch"}
    out["news"] = out["alpha"]
    out["persistence"] = out["alpha"] + out["beta"]
    return out


def garch_logvol(params, returns, horizon=HORIZON):
    omega, beta, alpha = params["omega"], params["beta"], params["alpha"]
    news, p = params["news"], params["persistence"]
    r = np.asarray(returns.values, float)
    eps = r - params["mu"]
    h = np.empty(len(r))
    h[0] = omega / max(1.0 - p, 1e-6) if p < 1 else float(np.var(eps))
    for t in range(1, len(r)):
        h[t] = omega + alpha * eps[t - 1] ** 2 + beta * h[t - 1]
    h_next = omega + news * eps ** 2 + beta * h
    h_bar = omega / max(1.0 - p, 1e-6)
    path = np.empty((len(r), horizon))
    for k in range(horizon):
        path[:, k] = h_bar + (p ** k) * (h_next - h_bar) if p < 1 else h_next
    mdv = path.mean(axis=1) / (100.0 ** 2)
    return pd.Series(np.log(np.sqrt(np.maximum(mdv, 1e-16))), index=returns.index)


# ---------- LSTM ----------
def make_sequences(values_2d, target_1d, seq_len):
    n = len(values_2d)
    if n < seq_len:
        return np.empty((0, seq_len, values_2d.shape[1])), np.empty((0,))
    w = np.arange(seq_len)[None, :] + np.arange(n - seq_len + 1)[:, None]
    return values_2d[w], target_1d[seq_len - 1:]


def build_lstm(n_features, seed=0):
    tf.keras.utils.set_random_seed(seed)
    m = Sequential([Input(shape=(SEQ_LEN, n_features)), LSTM(LSTM_UNITS),
                    Dropout(DROPOUT), Dense(1)])
    m.compile(optimizer=Adam(LR), loss="mse")
    return m


# ---------- unified interface ----------
def fit_source(kind, source, seed=0):
    if kind == "garch":
        params = fit_garch_params(source, seed)
        train = SPL[source][0]
        g = garch_logvol(params, RET[source]).reindex(train.index).dropna()
        y = train[TARGET].reindex(g.index)
        A = np.column_stack([np.ones(len(g)), g.values])
        c0, c1 = np.linalg.lstsq(A, y.values, rcond=None)[0]
        params["c0"], params["c1"] = float(c0), float(c1)
        return params, None, None, "garch"

    train = SPL[source][0]
    columns = HAR_COLS if kind == "har" else FEATS
    scaler = StandardScaler().fit(train[columns].values) if uses_scaler(kind) else None

    if kind == "lstm":
        val = SPL[source][1]
        xt, yt = make_sequences(apply_scaling(scaler, train, columns), train[TARGET].values, SEQ_LEN)
        xv, yv = make_sequences(apply_scaling(scaler, val, columns), val[TARGET].values, SEQ_LEN)
        model = build_lstm(len(columns), seed)
        model.fit(xt, yt, validation_data=(xv, yv), epochs=EPOCHS, batch_size=BATCH,
                  callbacks=[EarlyStopping(monitor="val_loss", patience=PATIENCE,
                                           restore_best_weights=True)], verbose=0)
        return model, columns, scaler, "lstm"

    model = make_model(kind, seed).fit(apply_scaling(scaler, train, columns), train[TARGET].values)
    return model, columns, scaler, kind


def predict_aligned(fitted, frame):
    obj, columns, scaler, kind = fitted
    if kind == "garch":
        market = MARKET_OF_FRAME[id(frame)]
        g = garch_logvol(obj, RET[market]).reindex(frame.index)
        ok = g.notna().values
        return frame.index[ok], frame[TARGET].values[ok], obj["c0"] + obj["c1"] * g.values[ok]
    scaled = apply_scaling(scaler, frame, columns)
    if kind == "lstm":
        xs, _ = make_sequences(scaled, frame[TARGET].values, SEQ_LEN)
        return (frame.index[SEQ_LEN - 1:], frame[TARGET].values[SEQ_LEN - 1:],
                obj.predict(xs, verbose=0).ravel())
    return frame.index, frame[TARGET].values, obj.predict(scaled)


print("model layers registered for:", MODELS)

# ============================================================================
# 5. Loss functions
# ============================================================================
def qlike(true_variance, pred_variance, eps=1e-10):
    ratio = true_variance / (pred_variance + eps)
    return float(np.mean(ratio - np.log(ratio + eps) - 1.0))


def log_to_variance(log_rv_pred, residual_log_var):
    return np.exp(2.0 * log_rv_pred + 2.0 * residual_log_var)


def rmse(y_true, y_pred):
    return float(np.sqrt(np.mean((y_true - y_pred) ** 2)))

# ============================================================================
# 6. Fit everything on a common index
# ============================================================================
BENCH_MEAN = {m: SPL[m][0][TARGET].mean() for m in MARKETS}

def oos_r2(y_true, y_pred, benchmark):
    return 1.0 - np.sum((y_true - y_pred) ** 2) / np.sum((y_true - benchmark) ** 2)

RAW_PRED, RESID_VAR, FITTED = {}, {}, {}
print("Fitting", len(MODELS), "models x", len(MARKETS), "source markets...")
for kind in MODELS:
    for source in MARKETS:
        fitted = fit_source(kind, source, seed=0)
        FITTED[(kind, source, 0)] = fitted
        _, v_true, v_pred = predict_aligned(fitted, SPL[source][1])
        RESID_VAR[(kind, source, 0)] = float(np.var(v_true - v_pred))   # VALIDATION
        for target in MARKETS:
            idx, t_true, t_pred = predict_aligned(fitted, SPL[target][2])
            RAW_PRED[(kind, source, target, 0)] = pd.Series(t_pred, index=idx)
    print("  ", LABEL[kind], "done")

# ---- the common index per target market ----
COMMON_IDX, TRUTH_C = {}, {}
for target in MARKETS:
    idx = None
    for kind in MODELS:
        for source in MARKETS:
            s = RAW_PRED[(kind, source, target, 0)].index
            idx = s if idx is None else idx.intersection(s)
    COMMON_IDX[target] = idx
    TRUTH_C[target] = SPL[target][2][TARGET].reindex(idx).values

print()
print("Common-index cost per target market:")
for target in MARKETS:
    full = len(SPL[target][2])
    print("  " + target.ljust(18) + str(full).rjust(5) + " test days ->"
          + str(len(COMMON_IDX[target])).rjust(5) + " common  (lost "
          + str(full - len(COMMON_IDX[target])) + ")")

# ---- per-day QLIKE loss on the common index, for every (model, source, target) ----
def loss_series(kind, source, target, seed=0):
    p = RAW_PRED[(kind, source, target, seed)].reindex(COMMON_IDX[target]).values
    true_var = np.exp(2.0 * TRUTH_C[target])
    pred_var = log_to_variance(p, RESID_VAR[(kind, source, seed)])
    ratio = true_var / (pred_var + 1e-10)
    return ratio - np.log(ratio + 1e-10) - 1.0

QL, R2M, RMSEM = {}, {}, {}
for kind in MODELS:
    ql = pd.DataFrame(index=MARKETS, columns=MARKETS, dtype=float)
    r2 = pd.DataFrame(index=MARKETS, columns=MARKETS, dtype=float)
    rm = pd.DataFrame(index=MARKETS, columns=MARKETS, dtype=float)
    for source in MARKETS:
        for target in MARKETS:
            ql.loc[source, target] = float(np.mean(loss_series(kind, source, target)))
            p = RAW_PRED[(kind, source, target, 0)].reindex(COMMON_IDX[target]).values
            r2.loc[source, target] = oos_r2(TRUTH_C[target], p, BENCH_MEAN[target])
            rm.loc[source, target] = float(np.sqrt(np.mean((TRUTH_C[target] - p) ** 2)))
    QL[kind], R2M[kind], RMSEM[kind] = ql, r2, rm
    ql.to_csv("results/cmp_qlike_" + kind + ".csv")
    r2.to_csv("results/cmp_r2_" + kind + ".csv")
    rm.to_csv("results/cmp_rmse_" + kind + ".csv")

off = ~np.eye(len(MARKETS), dtype=bool)
def gap(M):
    return M.sub(pd.Series(np.diag(M), index=M.columns), axis=1)
GAPS = {k: gap(QL[k]) for k in MODELS}
for k in MODELS:
    GAPS[k].to_csv("results/cmp_qlike_gap_" + k + ".csv")

# ---- persist the per-day loss series so nothing ever has to refit again ----
for target in MARKETS:
    frame = pd.DataFrame({LABEL[k] + "_" + s.split("_")[0]: loss_series(k, s, target)
                          for k in MODELS for s in MARKETS}, index=COMMON_IDX[target])
    frame.to_csv("results/losses_" + target + ".csv")
print()
print("per-day loss series written to results/losses_<market>.csv  (", len(MODELS) * len(MARKETS),
      "columns each )")

# ============================================================================
# 7. Headline comparison
# ============================================================================
rows = []
for kind in MODELS:
    own = float(np.diag(QL[kind]).mean())
    foreign = float(QL[kind].values[off].mean())
    sg = float(GAPS[kind].values[off].mean())
    ag = float(np.abs(GAPS[kind].values[off]).mean())
    har_anch = [float(QL[kind].loc[s, t] - QL["har"].loc[t, t])
                for s in MARKETS for t in MARKETS if s != t]
    rows.append({"model": LABEL[kind], "own_QLIKE": round(own, 4),
                 "foreign_QLIKE": round(foreign, 4),
                 "signed_gap": round(sg, 4), "abs_gap": round(ag, 4),
                 "abs_over_signed": round(ag / max(abs(sg), 1e-9), 1),
                 "HAR_anchored": round(float(np.mean(har_anch)), 4),
                 "beats_own_HAR": int(np.sum(np.array(har_anch) < 0)),
                 "own_RMSE_log": round(float(np.diag(RMSEM[kind]).mean()), 4)})
HEAD = pd.DataFrame(rows).sort_values("own_QLIKE").reset_index(drop=True)
HEAD.to_csv("results/cmp_headline.csv", index=False)
print("QLIKE, lower is better. beats_own_HAR counts foreign pairs beating the target's own HAR (of 20).")
print()
print(HEAD.to_string(index=False))
print()
flag = HEAD[HEAD.abs_over_signed > 3]
if len(flag):
    print("SIGN-CANCELLATION FLAG for:", ", ".join(flag.model),
          "- do NOT quote their signed_gap as a transfer cost.")
print()
DIAG = pd.DataFrame({LABEL[k]: np.diag(QL[k]) for k in MODELS}, index=MARKETS)
DIAG.to_csv("results/cmp_own_market.csv")
print("Own-market QLIKE by market (the dominant source of variation in this study):")
print(DIAG.round(4).to_string())
print()
print("market difficulty, averaged over models:")
print(DIAG.mean(axis=1).sort_values().round(4).to_string())

# ============================================================================
# 8. Six transfer matrices on one shared colour scale
# ============================================================================
ncol = 3
nrow = int(np.ceil(len(MODELS) / ncol))
allv = np.concatenate([QL[k].values.ravel() for k in MODELS])
norm = TwoSlopeNorm(vmin=float(allv.min()), vcenter=float(np.median(allv)), vmax=float(allv.max()))
fig, axes = plt.subplots(nrow, ncol, figsize=(4.6 * ncol, 4.0 * nrow))
axes = np.atleast_1d(axes).ravel()
short = [m.split("_")[0] for m in MARKETS]
for ax, kind in zip(axes, MODELS):
    A = QL[kind].values.astype(float)
    im = ax.imshow(A, cmap="RdBu_r", norm=norm)
    ax.set_xticks(range(len(MARKETS))); ax.set_xticklabels(short, rotation=45, ha="right", fontsize=7)
    ax.set_yticks(range(len(MARKETS))); ax.set_yticklabels(short, fontsize=7)
    ax.set_title(LABEL[kind] + "  own " + format(float(np.diag(A).mean()), ".3f"), fontsize=9)
    for i in range(len(MARKETS)):
        for j in range(len(MARKETS)):
            ax.text(j, i, format(A[i, j], ".3f"), ha="center", va="center", fontsize=6.3,
                    fontweight="bold" if i == j else "normal")
    for s in ax.spines.values():
        s.set_visible(False)
for ax in axes[len(MODELS):]:
    ax.axis("off")
fig.suptitle("QLIKE transfer matrices, shared colour scale (rows = trained on, columns = tested on)", y=1.0)
fig.tight_layout()
fig.savefig("figs/fig_cmp_matrices.png", bbox_inches="tight")
plt.close(fig)

# ============================================================================
# 9. The seed-noise floor
# ============================================================================
seed_rows = []
for kind in MODELS:
    if not IS_STOCHASTIC_KIND[kind]:
        seed_rows.append({"model": LABEL[kind], "n_seeds": 1, "own_sd": 0.0, "gap_sd": 0.0,
                          "note": "deterministic"})
        continue
    diag_s, gap_s = [], []
    for s in range(N_SEEDS):
        if s == 0:
            ql_s = QL[kind]
        else:
            ql_s = pd.DataFrame(index=MARKETS, columns=MARKETS, dtype=float)
            for source in MARKETS:
                fitted = fit_source(kind, source, seed=s)
                _, v_true, v_pred = predict_aligned(fitted, SPL[source][1])
                rv = float(np.var(v_true - v_pred))
                for target in MARKETS:
                    idx, _, p = predict_aligned(fitted, SPL[target][2])
                    p = pd.Series(p, index=idx).reindex(COMMON_IDX[target]).values
                    ql_s.loc[source, target] = qlike(np.exp(2.0 * TRUTH_C[target]),
                                                     log_to_variance(p, rv))
        diag_s.append(float(np.diag(ql_s).mean()))
        gap_s.append(float(gap(ql_s).values[off].mean()))
    seed_rows.append({"model": LABEL[kind], "n_seeds": N_SEEDS,
                      "own_sd": round(float(np.std(diag_s, ddof=1)), 5),
                      "gap_sd": round(float(np.std(gap_s, ddof=1)), 5),
                      "note": str(N_SEEDS) + " seeds"})
SEED = pd.DataFrame(seed_rows)
SEED.to_csv("results/cmp_seed_noise.csv", index=False)
print(SEED.to_string(index=False))

floor = float(SEED.own_sd.max())
spread = float(HEAD.own_QLIKE.max() - HEAD.own_QLIKE.min())
print()
print("between-model own-QLIKE spread = %.4f   worst seed sd = %.5f   ratio = %.1fx"
      % (spread, floor, spread / max(floor, 1e-12)))
print()
print("Pairwise separability of the model ranking against the noisiest model's floor:")
srt = HEAD.sort_values("own_QLIKE").reset_index(drop=True)
for i in range(len(srt) - 1):
    d = float(srt.own_QLIKE[i + 1] - srt.own_QLIKE[i])
    verdict = "separable" if d > 2 * floor else "NOT SEPARABLE - report as tied"
    print("  " + srt.model[i].ljust(13) + " vs " + srt.model[i + 1].ljust(13)
          + " diff " + format(d, ".4f") + "   " + verdict)

# ============================================================================
# 10. Paired moving-block bootstrap on model-minus-model differences
# ============================================================================
def block_indices(n_obs, n_boot, block, rng):
    n_blocks = int(np.ceil(n_obs / block))
    starts = rng.integers(0, max(n_obs - block, 1), size=(n_boot, n_blocks))
    idx = starts[:, :, None] + np.arange(block)[None, None, :]
    return idx.reshape(n_boot, -1)[:, :n_obs]


rng = np.random.default_rng(42)
BOOTI = {t: block_indices(len(COMMON_IDX[t]), N_BOOT, BLOCK, rng) for t in MARKETS}


def paired_ci(a, b, idx):
    d = (a - b)[idx]
    boot = d.mean(axis=1)
    lo, hi = np.percentile(boot, [2.5, 97.5])
    return float(d.mean()), float(lo), float(hi)


vs_bench = []
for target in MARKETS:
    bench = loss_series(BENCHMARK, target, target)
    for kind in MODELS:
        if kind == BENCHMARK:
            continue
        diff, lo, hi = paired_ci(loss_series(kind, target, target), bench, BOOTI[target])
        vs_bench.append({"market": target.split("_")[0], "model": LABEL[kind],
                         "mean_diff": round(diff, 4), "lo": round(lo, 4), "hi": round(hi, 4),
                         "verdict": "beats HAR" if hi < 0 else
                                    ("worse than HAR" if lo > 0 else "indistinguishable")})
VS = pd.DataFrame(vs_bench)
VS.to_csv("results/cmp_paired_vs_har.csv", index=False)
print("Own-market, model minus HAR (negative = model better; CI excluding 0 = significant)")
print()
print(VS.to_string(index=False))
print()
print("Count by verdict, per model:")
print(VS.pivot_table(index="model", columns="verdict", values="market",
                     aggfunc="count").fillna(0).astype(int).to_string())

# ============================================================================
# 11. Diebold–Mariano, reported as descriptive
# ============================================================================
def dm_test(loss_a, loss_b, horizon=HORIZON):
    """Diebold-Mariano with Newey-West HAC (h-1 lags) and the HLN small-sample correction."""
    d = np.asarray(loss_a, float) - np.asarray(loss_b, float)
    n = len(d)
    dbar = d.mean()
    dev = d - dbar
    gamma0 = float(np.mean(dev ** 2))
    lrv = gamma0
    for lag in range(1, horizon):                      # h - 1 autocovariances, Bartlett weights
        cov = float(np.mean(dev[lag:] * dev[:-lag]))
        lrv += 2.0 * (1.0 - lag / horizon) * cov
    lrv = max(lrv, 1e-16)
    stat = dbar / np.sqrt(lrv / n)
    hln = np.sqrt((n + 1 - horizon + horizon * (horizon - 1) / n) / n) if n > horizon else 1.0
    stat_hln = stat * hln
    p = 2.0 * (1.0 - student_t.cdf(abs(stat_hln), df=max(n - 1, 1)))
    return float(stat_hln), float(p)


dm_rows = []
for target in MARKETS:
    bench = loss_series(BENCHMARK, target, target)
    for kind in MODELS:
        if kind == BENCHMARK:
            continue
        stat, p = dm_test(loss_series(kind, target, target), bench)
        dm_rows.append({"market": target.split("_")[0], "model": LABEL[kind],
                        "DM_stat": round(stat, 3), "p_value": round(p, 4),
                        "direction": "model better" if stat < 0 else "HAR better",
                        "sig_5pct": bool(p < 0.05)})
DM = pd.DataFrame(dm_rows)
DM.to_csv("results/cmp_dm_vs_har.csv", index=False)
print("DM against HAR on each market's own forecasts (negative statistic favours the model)")
print()
print(DM.to_string(index=False))
print()
n_sig = int(DM.sig_5pct.sum())
print(n_sig, "of", len(DM), "comparisons significant at 5% WITHOUT multiplicity correction.")
print("Under the null and with", len(DM), "tests, roughly", round(0.05 * len(DM), 1),
      "would be expected by chance alone.")

# ============================================================================
# 12. The pooled Model Confidence Set
# ============================================================================
mcs_rows = []
survivor_counts = {LABEL[k]: 0 for k in MODELS}
own_slots = own_surv = foreign_slots = foreign_surv = 0

for target in MARKETS:
    series = {LABEL[k] + "_" + s.split("_")[0]: loss_series(k, s, target)
              for k in MODELS for s in MARKETS}
    L = pd.DataFrame(series, index=COMMON_IDX[target])
    assert L.shape[1] == len(MODELS) * len(MARKETS), L.shape
    mcs = MCS(L, size=0.05, reps=1000, block_size=BLOCK, bootstrap="stationary", seed=0)
    mcs.compute()
    included = sorted(mcs.included)                     # property, not a method
    best = L.mean(axis=0).idxmin()
    mcs_rows.append({"target": target, "n_candidates": L.shape[1], "n_in_MCS": len(included),
                     "lowest_mean_loss": best, "members": ", ".join(included)})
    print(target.ljust(18), str(len(included)).rjust(2), "of", L.shape[1],
          "survive | best:", best)

    tshort = target.split("_")[0]
    for k in MODELS:
        for s in MARKETS:
            cand = LABEL[k] + "_" + s.split("_")[0]
            is_own = (s == target)
            if is_own:
                own_slots += 1
            else:
                foreign_slots += 1
            if cand in included:
                survivor_counts[LABEL[k]] += 1
                if is_own:
                    own_surv += 1
                else:
                    foreign_surv += 1

MCS_TAB = pd.DataFrame(mcs_rows)
MCS_TAB.to_csv("results/cmp_mcs_pooled.csv", index=False)
print()
print("MCS membership by model (of", len(MARKETS) * len(MARKETS), "slots each):")
print(pd.Series(survivor_counts).sort_values(ascending=False).to_string())
print()
own_rate = own_surv / max(own_slots, 1)
for_rate = foreign_surv / max(foreign_slots, 1)
print("SURVIVAL RATES, the informative quantity (NOT the raw share of survivors):")
print("  own-market-trained    :", own_surv, "of", own_slots, "=", format(100 * own_rate, ".1f") + "%")
print("  foreign-market-trained:", foreign_surv, "of", foreign_slots, "=", format(100 * for_rate, ".1f") + "%")
print("  rate ratio (foreign / own) =", format(for_rate / max(own_rate, 1e-12), ".2f"))

# ============================================================================
# 13. The target-recalibration comparison
# ============================================================================
recal_rows = []
for kind in MODELS:
    for source in MARKETS:
        for target in MARKETS:
            if source == target:
                continue
            # strict: source's own residual variance
            strict = float(np.mean(loss_series(kind, source, target)))

            # recalibrated: same forecasts, residual variance re-estimated on the TARGET's
            # validation split using the SAME frozen model. Only the scalar changes.
            fitted = FITTED[(kind, source, 0)]
            _, v_true, v_pred = predict_aligned(fitted, SPL[target][1])
            rv_target = float(np.var(v_true - v_pred))
            p = RAW_PRED[(kind, source, target, 0)].reindex(COMMON_IDX[target]).values
            true_var = np.exp(2.0 * TRUTH_C[target])
            recal = qlike(true_var, log_to_variance(p, rv_target))

            own = float(np.mean(loss_series(kind, target, target)))
            recal_rows.append({"model": LABEL[kind], "trained_on": source.split("_")[0],
                               "tested_on": target.split("_")[0],
                               "gap_strict": round(strict - own, 4),
                               "gap_recalibrated": round(recal - own, 4),
                               "level_component": round(strict - recal, 4)})
RECAL = pd.DataFrame(recal_rows)
RECAL.to_csv("results/cmp_recalibration.csv", index=False)

summary = RECAL.groupby("model").agg(
    mean_gap_strict=("gap_strict", "mean"),
    mean_gap_recal=("gap_recalibrated", "mean"),
    mean_level_component=("level_component", "mean")).round(4).reset_index()
summary["pct_of_gap_that_is_level"] = (
    100 * summary.mean_level_component / summary.mean_gap_strict.abs().clip(lower=1e-9)).round(1)
print("Decomposition of the transfer gap, averaged over 20 foreign pairs per model")
print()
print(summary.to_string(index=False))
print()
worst = summary.loc[summary.pct_of_gap_that_is_level.idxmax()]
print("Largest level share:", worst.model, "at", str(worst.pct_of_gap_that_is_level) + "%")

# ============================================================================
# 14. Summary
# ============================================================================
print("=" * 78); print("CROSS-MODEL COMPARISON".center(78)); print("=" * 78)
print("models:", ", ".join(LABEL[k] for k in MODELS), "| GAP_POLICY =", GAP_POLICY,
      "|", len(FEATS), "shared features")
print("common index per target:", {m.split("_")[0]: len(COMMON_IDX[m]) for m in MARKETS})
print()
print(HEAD.to_string(index=False))
print()
print("=" * 78); print("SEPARABILITY".center(78)); print("=" * 78)
print(SEED[["model", "n_seeds", "own_sd", "gap_sd"]].to_string(index=False))
floor = float(SEED.own_sd.max())
srt = HEAD.sort_values("own_QLIKE").reset_index(drop=True)
best, second = srt.iloc[0], srt.iloc[1]
if float(second.own_QLIKE - best.own_QLIKE) > 2 * floor:
    print()
    print("Best model:", best.model, "at", best.own_QLIKE,
          "- margin over", second.model, "exceeds 2x the seed floor, so the ordering holds.")
else:
    print()
    print("TOP TWO NOT SEPARABLE:", best.model, "and", second.model,
          "differ by", round(float(second.own_QLIKE - best.own_QLIKE), 4))
    print("which is inside 2x the worst seed floor (" + format(floor, ".5f") + ").")
    print("Report them as jointly best. Do NOT rank them.")
print()
print("=" * 78); print("PAIRED TESTS vs HAR".center(78)); print("=" * 78)
print(VS.pivot_table(index="model", columns="verdict", values="market",
                     aggfunc="count").fillna(0).astype(int).to_string())
print()
print("=" * 78); print("POOLED MCS".center(78)); print("=" * 78)
print(MCS_TAB[["target", "n_candidates", "n_in_MCS", "lowest_mean_loss"]].to_string(index=False))
print()
print("=" * 78); print("RECALIBRATION: LEVEL vs PATTERN".center(78)); print("=" * 78)
print(summary.to_string(index=False))
print()
print("figures ->", sorted(os.listdir("figs")))
print("tables  ->", sorted(f for f in os.listdir("results") if f.startswith(("cmp_", "losses_"))))

# ============================================================================
# Fitted GARCH parameters (symmetric GARCH(1,1) and the GJR variant)
# ============================================================================
GARCH_VARIANTS = ("garch", "gjr")


def fit_garch_variant(source, variant="garch"):
    """MLE on the source market's training-split returns (normal innovations)."""
    r = RET[source].loc[:SPL[source][0].index.max()]
    if variant == "gjr":
        am = arch_model(r, vol="GARCH", p=1, o=1, q=1, mean="Constant", dist="normal")
    else:
        am = arch_model(r, vol="GARCH", p=1, q=1, mean="Constant", dist="normal")
    res = am.fit(disp="off", show_warning=False)
    p = res.params
    out = {"omega": float(p["omega"]), "alpha": float(p["alpha[1]"]), "beta": float(p["beta[1]"]),
           "gamma": float(p.get("gamma[1]", 0.0)), "mu": float(p["mu"]), "variant": variant,
           "loglik": float(res.loglikelihood)}
    out["news"] = out["alpha"] + (0.5 * out["gamma"] if variant == "gjr" else 0.0)
    out["persistence"] = out["news"] + out["beta"]
    return out


def garch_filter_variant(params, returns, horizon=HORIZON):
    omega, beta, alpha, gamma = params["omega"], params["beta"], params["alpha"], params["gamma"]
    news, p = params["news"], params["persistence"]
    r = np.asarray(returns.values, dtype=float)
    eps = r - params["mu"]
    h = np.empty(len(r))
    h[0] = omega / max(1.0 - p, 1e-6) if p < 1 else float(np.var(eps))
    for t in range(1, len(r)):
        shock = alpha * eps[t - 1] ** 2
        if params["variant"] == "gjr" and eps[t - 1] < 0:
            shock += gamma * eps[t - 1] ** 2
        h[t] = omega + shock + beta * h[t - 1]
    h_next = omega + news * eps ** 2 + beta * h
    h_bar = omega / max(1.0 - p, 1e-6)
    path = np.empty((len(r), horizon))
    for k in range(horizon):
        path[:, k] = h_bar + (p ** k) * (h_next - h_bar) if p < 1 else h_next
    mdv = path.mean(axis=1) / (100.0 ** 2)
    return pd.Series(np.log(np.sqrt(np.maximum(mdv, 1e-16))), index=returns.index)


param_rows = []
for variant in GARCH_VARIANTS:
    for source in MARKETS:
        p = fit_garch_variant(source, variant)
        train = SPL[source][0]
        g = garch_filter_variant(p, RET[source]).reindex(train.index).dropna()
        y = train[TARGET].reindex(g.index)
        A = np.column_stack([np.ones(len(g)), g.values])
        c0, c1 = np.linalg.lstsq(A, y.values, rcond=None)[0]
        param_rows.append({"variant": variant, "market": source,
                           "omega": round(p["omega"], 5), "alpha": round(p["alpha"], 4),
                           "gamma": round(p["gamma"], 4), "beta": round(p["beta"], 4),
                           "persistence": round(p["persistence"], 4),
                           "half_life_days": round(float(np.log(0.5) / np.log(max(p["persistence"], 1e-6))), 1)
                                             if p["persistence"] < 1 else np.inf,
                           "calib_c0": round(float(c0), 3), "calib_c1": round(float(c1), 3),
                           "loglik": round(p["loglik"], 1)})
PARAM_TAB = pd.DataFrame(param_rows)
PARAM_TAB.to_csv("results/table_garch_parameters.csv", index=False)
print(PARAM_TAB.to_string(index=False))


# ============================================================================
# India-only ablation: does the variance risk premium help?
# ============================================================================
if HAVE_VIX:
    india_vix = vix_raw["Close"].rename("india_vix")
    india_realised = parkinson_vol(raw["India_NIFTY50"], 21) * np.sqrt(252) * 100
    vrp_frame = pd.DataFrame({"india_vix": india_vix, "realised_ann": india_realised}).dropna()
    vrp_frame["vrp"] = vrp_frame["india_vix"] - vrp_frame["realised_ann"]

    india_ext = data["India_NIFTY50"].join(vrp_frame[["vrp"]], how="inner").dropna()
    train_v = india_ext.loc[:TRAIN_END].iloc[:-PURGE]
    val_v = india_ext.loc[TRAIN_END:VAL_END].iloc[PURGE:-PURGE]
    test_v = india_ext.loc[VAL_END:].iloc[PURGE:]
    print("VRP ablation test window:", test_v.index.min().date(), "to", test_v.index.max().date(),
          "(" + str(len(test_v)) + " rows; narrower than the main test window because India VIX and")
    print("NIFTY are inner-joined on date)")

    vrp_rows = []
    for kind in [k for k in MODELS if k != "garch"]:
        base_cols = HAR_COLS if kind == "har" else FEATS
        ext_cols = base_cols + ["vrp"]

        if kind == "lstm":
            def vrp_fit_predict(columns, seed=0):
                scaler = StandardScaler().fit(train_v[columns].values)
                xt, yt = make_sequences(apply_scaling(scaler, train_v, columns), train_v[TARGET].values, SEQ_LEN)
                xv, yv = make_sequences(apply_scaling(scaler, val_v, columns), val_v[TARGET].values, SEQ_LEN)
                xs, ys = make_sequences(apply_scaling(scaler, test_v, columns), test_v[TARGET].values, SEQ_LEN)
                model = build_lstm(len(columns), seed)
                model.fit(xt, yt, validation_data=(xv, yv), epochs=EPOCHS, batch_size=BATCH,
                          callbacks=[EarlyStopping(monitor="val_loss", patience=PATIENCE,
                                                   restore_best_weights=True)], verbose=0)
                rv = float(np.var(yv - model.predict(xv, verbose=0).ravel()))
                return model.predict(xs, verbose=0).ravel(), ys, rv
        else:
            def vrp_fit_predict(columns, seed=0, kind=kind):
                scaler = StandardScaler().fit(train_v[columns].values) if uses_scaler(kind) else None
                def tx(frame):
                    if scaler is None:
                        return frame[columns].values
                    z = scaler.transform(frame[columns].values)
                    return np.clip(z, -CLIP_Z, CLIP_Z) if GAP_POLICY == "clip" else z
                model = make_model(kind, seed).fit(tx(train_v), train_v[TARGET].values)
                rv = float(np.var(val_v[TARGET].values - model.predict(tx(val_v))))
                return model.predict(tx(test_v)), test_v[TARGET].values, rv

        p_base, y_base, rv_base = vrp_fit_predict(base_cols)
        p_ext, y_ext, rv_ext = vrp_fit_predict(ext_cols)
        ql_base = qlike(np.exp(2.0 * y_base), log_to_variance(p_base, rv_base))
        ql_ext = qlike(np.exp(2.0 * y_ext), log_to_variance(p_ext, rv_ext))
        r2_base = oos_r2(y_base, p_base, train_v[TARGET].mean())
        r2_ext = oos_r2(y_ext, p_ext, train_v[TARGET].mean())
        vrp_rows.append({"model": LABEL[kind], "QLIKE_without_vrp": round(ql_base, 4),
                         "QLIKE_with_vrp": round(ql_ext, 4),
                         "change_pct": round(100.0 * (ql_ext - ql_base) / ql_base, 1),
                         "R2_without_vrp": round(r2_base, 3), "R2_with_vrp": round(r2_ext, 3)})
        print(LABEL[kind].ljust(14), "without:", round(ql_base, 4), " with:", round(ql_ext, 4))
    VRP_TAB = pd.DataFrame(vrp_rows)
    VRP_TAB.to_csv("results/table_vrp_ablation.csv", index=False)
    print()
    print(VRP_TAB.to_string(index=False))
else:
    print("India VIX unavailable; the VRP ablation was skipped.")


# ============================================================================
# Run record: library versions, settings and data dates
# ============================================================================
import json
import platform
import sys
from importlib import metadata


def _version(pkg):
    try:
        return metadata.version(pkg)
    except Exception:
        return None


run_info = {
    "python": sys.version.split()[0],
    "platform": platform.platform(),
    "packages": {p: _version(p) for p in ("numpy", "pandas", "scipy", "scikit-learn", "xgboost", "arch",
                                          "tensorflow", "matplotlib", "pyarrow", "requests")},
    "settings": {"tickers": TICKERS, "download_window": [DL_START, DL_END], "window_start": WIN_START,
                 "horizon": HORIZON, "train_end": TRAIN_END, "val_end": VAL_END, "n_seeds": N_SEEDS,
                 "n_boot": N_BOOT, "block": BLOCK, "gap_policy": GAP_POLICY, "models": MODELS},
    "data": {name: {"rows": int(len(raw[name])), "first": str(raw[name].index.min().date()),
                    "last": str(raw[name].index.max().date()),
                    "file_modified": pd.Timestamp(os.path.getmtime(os.path.join("data_raw", name + ".parquet")),
                                                  unit="s").isoformat()}
             for name in MARKETS},
}
with open("results/run_info.json", "w") as handle:
    json.dump(run_info, handle, indent=2)
print("run record -> results/run_info.json")
